# dclake: data lake de viabilidad de data centers (España, 5×5 km, 20 años)

Pipeline en Python que descarga datos públicos y los organiza **siguiendo exactamente el diccionario de datos** (`data_dictionary/diccionario_datos_datacenters.xlsx`) para entrenar el modelo de viabilidad del hackathon.

- **Territorio:** España (península, Baleares y Canarias) en una rejilla de celdas de 5×5 km (ETRS89-LAEA, EPSG:3035: todas miden exactamente 25 km²). Salen ~20.200 celdas.
- **Muestra:** 500 celdas estratificadas: las que contienen un data center conocido, 75 en Madrid y 75 en Aragón, y el resto al azar.
- **Tiempo:** 1 nov 2006 – 31 oct 2026. Diario para lo que cambia a diario (clima, precio eléctrico, terremotos, incendios), anual para indicadores económicos y agregados climáticos, estático para el resto.
- **Diccionario como fuente de verdad:** cada uno de los 494 campos (y las variables diarias) existe como columna aunque ningún colector lo rellene todavía. El informe de cobertura dice cuáles tienen datos y por qué faltan los demás.

## Instalación (Windows)

1. Instala [Miniforge](https://github.com/conda-forge/miniforge) (conda). En Windows las librerías geoespaciales se instalan mucho mejor con conda que con pip.
2. Abre **Miniforge Prompt** en la carpeta del proyecto:
   ```
   conda env create -f environment.yml
   conda activate dclake
   python -m pytest -q tests
   python -m dclake demo
   ```
   La demo funciona sin internet con datos sintéticos y comprueba que todo está bien instalado.
3. `python -m dclake init` crea el archivo `.env` y muestra qué claves y archivos faltan.

## Claves (todas gratuitas, ninguna obligatoria)

| Variable | Para qué | Dónde |
|---|---|---|
| `CDSAPI_KEY` | Clima ERA5-Land horario → diario | cds.climate.copernicus.eu (acepta la licencia del dataset *ERA5-Land hourly time-series*) |
| `FIRMS_MAP_KEY` | Incendios diarios | firms.modaps.eosdis.nasa.gov/api/map_key |
| `PEERINGDB_API_KEY` | Opcional, evita límites | peeringdb.com |

Sin clave, el colector correspondiente se salta con un aviso y el resto sigue.

## Capas manuales

Algunas fuentes exigen registro o formulario (WDPA, GEM, Aqueduct, HydroSHEDS, SNCZI, GHSL…). `config.yaml → manual_layers` lista cada archivo, dónde descargarlo y qué campos rellena. Déjalos en `data_lake/raw/manual/<ruta del config>`. **Comprueba los nombres de atributos** (por ejemplo `bws_score` en Aqueduct) al descargarlos, porque cambian entre versiones.

## Ejecución

```
python -m dclake grid                                   # rejilla + muestra (minutos)
python -m dclake collect --only osm --limit-sites 5     # probar un colector con 5 celdas
python -m dclake collect                                # todos (horas: mejor de noche)
python -m dclake collect --only era5land,firms          # o por partes
python -m dclake assemble                               # tablas finales + informe de cobertura
```

Todo es **reanudable**: las descargas se guardan en `data_lake/raw/` y no se repiten.

Tiempos orientativos con 500 celdas: OSM 10–30 min (consultas grandes a Overpass, a veces hay que reintentar); ERA5-Land 500 peticiones (de minutos a horas según la cola del CDS); OMIE ~7.300 archivos (30–60 min); FIRMS ~730 peticiones; sísmica varias horas (configurable en `seismic.days_per_year`).

## Qué sale

`data_lake/tables/`:

| Tabla | Una fila por | Origen en el diccionario |
|---|---|---|
| `sites_static.parquet` | celda | campos de `sites` con temporalidad *Estático* |
| `sites_yearly.parquet` | celda × año | campos de `sites` *Anual* (agregados climáticos, precios, macro) |
| `sites_daily/year=AAAA/` | celda × día | hoja *Variables diarias* |
| `country_daily.parquet` | país × día | precio OMIE, mix REE, EUR/USD |
| `country_context.parquet` | país × año (8 países) | bloque 13 |
| `stations.parquet` | estación sísmica | bloque 12 |
| `signal_features.parquet` | grabación analizada | bloque 11 |
| `field_lineage.parquet` | campo | bloque 15: fuente, licencia, fecha, si es sintético, cobertura |

`data_lake/reports/coverage.csv` dice para cada campo: *con datos*, *sin datos (revisar clave/archivo/log)*, *pendiente* (fuente identificada, colector por hacer) o *sin colector*.

## Estructura

```
config.yaml                 parámetros, fuentes y capas manuales
data_dictionary/            diccionario (xlsx) y build_dict.py que lo genera
src/dclake/
  grid.py                   rejilla 5x5 km y muestreo estratificado
  schema.py                 lee el diccionario y define las tablas
  assemble.py               une las salidas de los colectores en las tablas
  report.py                 informe de cobertura
  hv.py                     H/V (Nakamura), criterios SESAME, PSD, features espectrales
  collectors/               un archivo por fuente; pending.py lista lo que falta
tests/                      tests offline
```

Para añadir una fuente: crea una clase `Collector` (ver `collectors/base.py`) con `fields = {"tabla": [campos del diccionario]}`, implementa `run(sites)` llamando a `self.stage(tabla, df)` y regístrala en `collectors/__init__.py`. Para añadir campos al diccionario, edita `data_dictionary/build_dict.py` y regenera el xlsx.

## Limitaciones conocidas

- Los colectores se escribieron sin poder llamar a las APIs reales. La lógica de cálculo está probada offline (H/V, acumulados de ERA5, parser de OMIE, esquema), pero **cada colector debe validarse con `--limit-sites 3`** la primera vez. Puntos concretos: formato de salida del dataset CDS de series temporales, columna del precio español en los archivos de OMIE, códigos WGI en la API del Banco Mundial y campos de PeeringDB.
- El H/V de cada celda viene de la estación más cercana: es un **indicador regional**, no una medida de la parcela (`hv_confidence` lo refleja).
- PUE, WUE e intensidad de carbono salen de modelos simplificados con supuestos en `config.yaml`; están marcados en `field_lineage`.
- Licencias no comerciales: GEM y UICN. Válidas para el hackathon, no para un producto sin acuerdo.
