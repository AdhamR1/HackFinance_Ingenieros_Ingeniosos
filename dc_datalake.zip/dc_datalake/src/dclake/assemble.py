"""Merge staged collector outputs into the final tables defined by the dictionary."""
from __future__ import annotations

from datetime import datetime, timezone

import numpy as np
import pandas as pd

from .schema import TableSpec, conform, load_schemas


def _base_keys(lake, cfg, table: str, year: int | None = None) -> pd.DataFrame | None:
    sites = lake.sites()
    p = cfg["period"]
    y0, y1 = pd.Timestamp(p["start"]).year, pd.Timestamp(p["end"]).year
    if table == "sites_static":
        return sites[["site_id"]].copy()
    if table == "sites_yearly":
        return sites[["site_id"]].merge(pd.DataFrame({"year": range(y0, y1 + 1)}), how="cross")
    if table == "country_context":
        return pd.MultiIndex.from_product([cfg["countries"], range(y0, y1 + 1)],
                                          names=["country_iso3", "year"]).to_frame(index=False)
    if table == "sites_daily":
        days = pd.date_range(p["start"], p["end"], freq="D")
        days = days[days.year == year]
        return pd.MultiIndex.from_product([sites["site_id"].values, days], names=["site_id", "date"]).to_frame(index=False)
    if table == "country_daily":
        return pd.DataFrame({"country_iso3": cfg["project"]["country_iso3"],
                             "date": pd.date_range(p["start"], p["end"], freq="D")})
    return None  # stations, signal_features: union of staged keys


def _norm_keys(df: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    df = df.copy()
    for k in keys:
        if k == "date":
            df[k] = pd.to_datetime(df[k]).dt.normalize()
        elif k == "year":
            df[k] = pd.to_numeric(df[k]).astype(int)
        else:
            df[k] = df[k].astype(str)
    return df


def merge_staged(lake, cfg, spec: TableSpec, collectors: list[str], year: int | None = None,
                 provenance: dict | None = None) -> pd.DataFrame:
    """Combine all staged frames for one table. Earlier collectors win on conflicts."""
    keys = spec.keys
    frames = []
    for c in collectors:
        df = lake.read_stage(c, spec.name, year if spec.partition_by_year else None)
        if df is not None and len(df):
            frames.append((c, _norm_keys(df, keys)))
    base = _base_keys(lake, cfg, spec.name, year)
    if base is None:
        if not frames:
            return pd.DataFrame(columns=spec.columns)
        idx = pd.concat([f[keys] for _, f in frames]).drop_duplicates()
        base = idx
    base = _norm_keys(base, keys).drop_duplicates(keys).set_index(keys)
    for c, df in frames:
        d = df.drop_duplicates(keys, keep="last").set_index(keys)
        for col in d.columns:
            if col not in spec.fields:
                continue
            new = d[col].reindex(base.index)
            if col in base.columns:
                before = base[col].notna().sum()
                base[col] = base[col].astype(object).where(base[col].notna(), new.astype(object))
                gained = base[col].notna().sum() - before
            else:
                base[col] = new
                gained = new.notna().sum()
            if provenance is not None and gained > 0:
                provenance.setdefault(col, [])
                if c not in provenance[col]:
                    provenance[col].append(c)
    return base.reset_index()


def assemble(lake, cfg, collectors: list[str] | None = None):
    specs = load_schemas(cfg.dictionary_path)
    collectors = collectors or lake.staged_collectors()
    log = lake.log
    lineage_rows = []
    lineage_info = {c: lake.read_lineage(c) for c in collectors}
    now = datetime.now(timezone.utc)

    def add_lineage(spec, df, prov):
        for f in spec.fields:
            if f in spec.keys:
                continue
            cov = float(df[f].notna().mean() * 100) if f in df and len(df) else 0.0
            srcs = prov.get(f, [])
            info = {}
            for c in srcs:
                li = lineage_info.get(c, {})
                info = li.get(f"{spec.name}.{f}") or li.get("*", {})
                if info:
                    break
            lineage_rows.append({"table": spec.name, "field": f, "collector": ",".join(srcs) or None,
                                 "coverage_pct": cov, "n_rows": len(df), **info})

    for name in ("sites_static", "sites_yearly", "country_context", "country_daily", "stations", "signal_features"):
        spec = specs[name]
        prov = {}
        df = merge_staged(lake, cfg, spec, collectors, provenance=prov)
        df = conform(df, spec, log, strict=False)
        df.to_parquet(lake.tables / f"{name}.parquet", index=False)
        add_lineage(spec, df, prov)
        log.info("Tabla %-16s %8d filas x %3d columnas", name, len(df), df.shape[1])

    # sites_daily, one partition per year
    spec = specs["sites_daily"]
    p = cfg["period"]
    years = range(pd.Timestamp(p["start"]).year, pd.Timestamp(p["end"]).year + 1)
    prov, n_total, nn = {}, 0, {}
    for y in years:
        df = merge_staged(lake, cfg, spec, collectors, year=y, provenance=prov)
        df = conform(df, spec, log, strict=False)
        out = lake.tables / "sites_daily" / f"year={y}"
        out.mkdir(parents=True, exist_ok=True)
        df.to_parquet(out / "part-0.parquet", index=False)
        n_total += len(df)
        for f in spec.fields:
            nn[f] = nn.get(f, 0) + int(df[f].notna().sum())
    for f in spec.fields:
        if f in spec.keys:
            continue
        info = {}
        for c in prov.get(f, []):
            li = lineage_info.get(c, {})
            info = li.get(f"sites_daily.{f}") or li.get("*", {})
            if info:
                break
        lineage_rows.append({"table": "sites_daily", "field": f, "collector": ",".join(prov.get(f, [])) or None,
                             "coverage_pct": 100 * nn.get(f, 0) / max(n_total, 1), "n_rows": n_total, **info})
    log.info("Tabla %-16s %8d filas (particionada por año)", "sites_daily", n_total)

    lin = pd.DataFrame(lineage_rows)
    lin["reference_year"] = np.where(lin["table"].isin(["sites_daily", "sites_yearly", "country_context", "country_daily"]),
                                     np.nan, now.year)
    lin = conform(lin, specs["field_lineage"], log, strict=False)
    lin.to_parquet(lake.tables / "field_lineage.parquet", index=False)
    return lin
