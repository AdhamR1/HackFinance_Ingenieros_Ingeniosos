"""Data lake de viabilidad de data centers (hackathon)."""
__version__ = "0.1.0"
