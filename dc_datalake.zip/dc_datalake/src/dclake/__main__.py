"""Command line: python -m dclake <command> [options]

  init       crea carpetas y .env, y muestra qué claves y archivos faltan
  status     igual que init pero sin crear nada
  grid       rejilla 5x5 km de España y muestra estratificada de celdas
  collect    ejecuta los colectores (--only / --skip / --limit-sites)
  assemble   une todo en las tablas del diccionario
  report     informe de cobertura por campo y bloque
  all        grid + collect + assemble + report
  demo       ejecución offline con datos sintéticos (comprueba la instalación)
"""
from __future__ import annotations

import argparse
import shutil
import sys
import time
from pathlib import Path


def _setup(args):
    from .config import load_config
    from .lake import Lake
    cfg = load_config(args.config)
    lake = Lake(cfg.lake)
    return cfg, lake


def cmd_status(cfg, lake, create=False):
    from .collectors import REGISTRY
    root = cfg.root
    env, example = root / ".env", root / ".env.example"
    if create and not env.exists() and example.exists():
        shutil.copy(example, env)
        lake.log.info("Creado %s: rellena tus claves ahí", env)
    lake.log.info("Claves de API:")
    for cls in REGISTRY:
        c = cls(lake, cfg)
        if c.status == "pendiente":
            continue
        miss = c.missing_requirements()
        if c.requires or miss:
            lake.log.info("  %-18s %s", c.name, "OK" if not miss else f"FALTA {miss}")
    lake.log.info("Capas manuales (en %s):", lake.manual)
    for layer in cfg.get("manual_layers", []):
        ok = (lake.manual / layer["file"]).exists()
        lake.log.info("  %-16s %s  %s", layer["name"], "OK   " if ok else "FALTA", "" if ok else layer.get("download", ""))


def cmd_collect(cfg, lake, only=None, skip=None, limit=None):
    from .collectors import REGISTRY
    sites = lake.sites()
    if limit:
        sites = sites.head(limit)
        lake.log.info("Modo prueba: %d celdas", len(sites))
    results = {}
    for cls in REGISTRY:
        if only and cls.name not in only:
            continue
        if skip and cls.name in skip:
            continue
        c = cls(lake, cfg)
        t0 = time.time()
        try:
            ok = c(sites)
            results[c.name] = "ok" if ok else ("pendiente" if c.status == "pendiente" else "omitido")
        except KeyboardInterrupt:
            raise
        except Exception as e:  # one failing source must not stop the rest
            lake.log.exception("[%s] ERROR: %s", c.name, e)
            results[c.name] = f"error: {e}"
        lake.log.info("[%s] %s (%.0f s)", c.name, results[c.name], time.time() - t0)
    lake.log.info("Resumen: %s", results)
    return results


def main(argv=None):
    ap = argparse.ArgumentParser(prog="dclake", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["init", "status", "grid", "collect", "assemble", "report", "all", "demo"])
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--only", help="colectores separados por comas")
    ap.add_argument("--skip", help="colectores separados por comas")
    ap.add_argument("--limit-sites", type=int, help="usar solo las N primeras celdas (pruebas)")
    args = ap.parse_args(argv)
    only = set(args.only.split(",")) if args.only else None
    skip = set(args.skip.split(",")) if args.skip else None

    if args.command == "demo":
        from .demo import run_demo
        run_demo(Path(args.config).resolve().parent)
        return 0

    cfg, lake = _setup(args)
    from .collectors import REGISTRY
    if args.command in ("init", "status"):
        cmd_status(cfg, lake, create=args.command == "init")
    if args.command in ("grid", "all"):
        from .grid import run_grid
        run_grid(lake, cfg)
    if args.command in ("collect", "all"):
        cmd_collect(cfg, lake, only, skip, args.limit_sites)
    if args.command in ("assemble", "all"):
        from .assemble import assemble
        assemble(lake, cfg)
    if args.command in ("report", "all", "assemble"):
        from .report import coverage_report
        coverage_report(lake, cfg, REGISTRY)
    return 0


if __name__ == "__main__":
    sys.exit(main())
