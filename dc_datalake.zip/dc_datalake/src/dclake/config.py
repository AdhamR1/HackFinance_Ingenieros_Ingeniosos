"""Load config.yaml and secrets from .env / environment variables."""
from __future__ import annotations

import os
from pathlib import Path

import yaml

try:
    from dotenv import load_dotenv
except ImportError:  # optional
    load_dotenv = None


class Config(dict):
    """dict with attribute access and resolved paths."""

    def __getattr__(self, k):
        try:
            v = self[k]
        except KeyError as e:
            raise AttributeError(k) from e
        return Config(v) if isinstance(v, dict) and not isinstance(v, Config) else v

    @property
    def root(self) -> Path:
        return Path(self["_root"])

    @property
    def lake(self) -> Path:
        return self.root / self["paths"]["lake_dir"]

    @property
    def dictionary_path(self) -> Path:
        return self.root / self["paths"]["dictionary"]

    def secret(self, name: str) -> str | None:
        v = os.environ.get(name)
        return v.strip() if v and v.strip() else None


def load_config(path: str | Path = "config.yaml", overrides: dict | None = None) -> Config:
    path = Path(path).resolve()
    if load_dotenv is not None:
        load_dotenv(path.parent / ".env")
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    data["_root"] = str(path.parent)
    for k, v in (overrides or {}).items():
        sec, _, key = k.partition(".")
        data.setdefault(sec, {})[key] = v
    return Config(data)
