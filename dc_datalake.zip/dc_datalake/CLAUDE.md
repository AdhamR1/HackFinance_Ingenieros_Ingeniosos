# CLAUDE.md: contexto del proyecto para Claude Code

## Qué es
Hackathon de finanzas (equipo de 5, 4 días). Herramienta de **cribado de viabilidad de parcelas para data centers** que combina análisis de ruido sísmico ambiental (método H/V) con capas de energía, agua, clima, riesgos, conectividad, economía, regulación y biodiversidad, y devuelve una puntuación, un coste por MW y un informe generado por Claude. Es un cribado inicial, no un estudio geotécnico.

Este repositorio es la parte de **datos**: construye el data lake del que se entrena el modelo.

## Reglas
- **El diccionario manda.** `data_dictionary/diccionario_datos_datacenters.xlsx` define tablas, campos, tipos, temporalidad y prioridad. No crees columnas fuera de él: `schema.conform` las descarta. Para añadir o cambiar campos, edita `data_dictionary/build_dict.py`, regenera el xlsx (`python build_dict.py` dentro de esa carpeta) y luego el código.
- **No inventes datos.** Si una fuente no está disponible, el campo queda nulo y aparece en el informe de cobertura. Cualquier valor simulado o de modelo se marca en el linaje (`is_synthetic`, `imputation_method`, `notes`).
- **Linaje siempre.** Cada colector declara `fields`, `source`, `license`. Lo que no venga de la fuente tal cual lleva nota.
- **Windows primero.** El equipo ejecuta en portátiles con Windows: `pathlib`, nada de `:` en nombres de archivo, nada de comandos de shell propios de Linux en el código, dependencias instalables con conda-forge.
- **Reanudable e idempotente.** Toda descarga pasa por `lake.cached_get` (caché en `data_lake/raw/`). Un colector que falla no debe parar a los demás.
- **Educado con las APIs.** Respeta límites (sleep entre peticiones, reintentos con backoff), términos de uso y robots.txt. Nada de scraping de portales que lo prohíban.
- **Licencias.** GEM y UICN son no comerciales. Anótalo en el linaje.
- Código y comentarios en inglés; documentación, logs y mensajes al usuario en español.

## Comandos
```
conda activate dclake
python -m pytest -q tests                 # tests offline
python -m dclake demo                      # pipeline completo con datos sintéticos
python -m dclake status                    # claves y capas manuales que faltan
python -m dclake grid
python -m dclake collect --only <nombre> --limit-sites 3
python -m dclake collect
python -m dclake assemble                  # tablas + reports/coverage.csv
```

## Arquitectura
- `grid.py`: rejilla 5x5 km en EPSG:3035 sobre geoBoundaries y muestra estratificada de 500 celdas (`site_id = ESP_<x/5000>_<y/5000>`).
- `collectors/*.py`: cada uno escribe DataFrames a `data_lake/staging/<colector>/<tabla>.parquet` (las tablas diarias por año). Orden en `collectors/__init__.py`: si dos colectores rellenan el mismo campo, gana el primero. `derived` va siempre el último.
- `assemble.py`: combina el staging en `data_lake/tables/` con el esquema del diccionario y escribe `field_lineage`.
- `report.py`: cobertura por campo y bloque.
- `hv.py`: H/V con suavizado Konno-Ohmachi y criterios SESAME, PSD frente al modelo de Peterson y features espectrales. Probado con señales sintéticas.

## Estado
Ver `PROMPT_CLAUDE_CODE.md` (tareas pendientes) y `data_lake/reports/coverage.csv` tras cada ejecución.
